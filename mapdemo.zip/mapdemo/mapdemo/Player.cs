﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mapdemo
{
    public class Player
    {
        public int X = 0;
        public int Y = 0;
    }
}
