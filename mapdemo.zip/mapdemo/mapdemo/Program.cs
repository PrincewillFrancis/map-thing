﻿using System;
namespace mapdemo
{

    public class Program
    {
        public static void Main()
        {
            Map map = new Map();
            map.CreateMap();
            map.ShowMap();

        }
    }

}