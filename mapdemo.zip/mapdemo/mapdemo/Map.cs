﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mapdemo
{
    public class Map
    {
        int rows = 3; //x
        int columns = 3; //y
        Player player = new Player();
        public Location[,] MapArray;

        public void CreateMap()
        {

            //when you make your array, the [,] will hold [x, y]
            //example with 2 rows and 2 columns
            //map = new string[rows, columns];

            //hardcoded example
           // MapArray = new Location[,] {};
           MapArray = new Location[rows, columns];

            //nested loop to set up the "map"
            for (int i = 0; i <rows; i++) 
            {
                for (int j = 0; j < columns; j++) 
                {
                    MapArray[i, j] = new Location() { Name = "a"};
                
                }
            
            }

            //if not one of those things, it's gotta be something else
            //

        }

        public void ShowMap()
        {
            for (int row = 0; row < rows; row++)
            {
                for (int column = 0; column < columns; column++)
                {
                    if (player.X == row && player.Y == column)  
                    {
                        Console.BackgroundColor = ConsoleColor.White;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("||x||");
                    }

                    else
                    {
                        Console.Write(MapArray[row, column].Name + "");
                        Console.Write($"   ");
                        Console.ResetColor();
                    }
                    
                }
                Console.Write("\n"); //this adds a new line

            

            }
        }

    }
}

//Console.WriteLine(MapArray[player.X,player.Y].Name)};