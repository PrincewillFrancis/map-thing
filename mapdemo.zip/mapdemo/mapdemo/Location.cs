﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mapdemo
{
    public enum GeologicalFeature 
    {
        Mountain,
        Deset,
        Rainforest,
        Tundra
    
    }
    public class Location
    {
        public string Name;
        public GeologicalFeature Feature = GeologicalFeature.Rainforest;
        public string Description;
        public ConsoleColor color = ConsoleColor.Green;

        public Location() 
        {
        
        }
    }
}
